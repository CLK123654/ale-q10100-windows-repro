import { test, expect } from 'playwright/test';
import crypto from 'node:crypto';
import fsSync from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';

type QueueItem = {
  queue_item_id: string;
  event_id: string;
  assigned_role: string;
  review_batch: string;
  received_at_utc: string;
};

const inputRoot = process.env.ALE_INPUT_ROOT || process.cwd();
const outputRoot = process.env.ALE_OUTPUT_ROOT || path.join(inputRoot, 'output');
const reportsDir = path.join(outputRoot, 'reports');
const events = JSON.parse(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'risk_login_events.json'), 'utf8'));
const policy = JSON.parse(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'freeze_policy.json'), 'utf8'));
const roles = JSON.parse(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'admin_roles.json'), 'utf8'));
const queueCsv = fsSync.readFileSync(path.join(inputRoot, 'queues', 'review_queue.csv'), 'utf8').trim();

function parseCsv(text: string): QueueItem[] {
  const [header, ...rows] = text.split(/\r?\n/);
  const keys = header.split(',');
  return rows.filter(Boolean).map((row) => Object.fromEntries(row.split(',').map((value, index) => [keys[index], value])) as QueueItem);
}

function base32Decode(secret: string): Buffer {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const char of secret.replace(/=+$/g, '').toUpperCase()) {
    const value = alphabet.indexOf(char);
    if (value < 0) throw new Error(`invalid base32 character: ${char}`);
    bits += value.toString(2).padStart(5, '0');
  }
  const bytes: number[] = [];
  for (let index = 0; index + 8 <= bits.length; index += 8) bytes.push(Number.parseInt(bits.slice(index, index + 8), 2));
  return Buffer.from(bytes);
}

function totpAt(counter: number): string {
  if (policy.totp.algorithm !== 'HMAC-SHA1') throw new Error(`unsupported TOTP algorithm: ${policy.totp.algorithm}`);
  const buffer = Buffer.alloc(8);
  buffer.writeBigUInt64BE(BigInt(counter));
  const digest = crypto.createHmac('sha1', base32Decode(policy.totp.secret_base32)).update(buffer).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary = ((digest[offset] & 0x7f) << 24)
    | ((digest[offset + 1] & 0xff) << 16)
    | ((digest[offset + 2] & 0xff) << 8)
    | (digest[offset + 3] & 0xff);
  return String(binary % (10 ** policy.totp.digits)).padStart(policy.totp.digits, '0');
}

function decide(event: any) {
  if (event.account_status === 'locked') return { decision: 'skip_locked', reasonCode: policy.decision_reasons.already_locked };
  if (event.account_type === 'staff') return { decision: 'escalate_staff', reasonCode: policy.decision_reasons.staff_escalation };
  if (event.account_type === 'service') return { decision: 'escalate_service', reasonCode: policy.decision_reasons.service_account_escalation };
  const signal = policy.freeze_high_risk.reason_priority.find((item: string) => event.signals.includes(item));
  if (event.risk_score >= policy.freeze_high_risk.min_score && signal) {
    return { decision: 'freeze', reasonCode: policy.decision_reasons.signal_reason_codes[signal] };
  }
  if (event.risk_score >= policy.review_min_score) return { decision: 'manual_review', reasonCode: policy.decision_reasons.manual_review };
  return { decision: 'monitor', reasonCode: policy.decision_reasons.monitor };
}

function csvEscape(value: unknown): string {
  const text = String(value ?? '');
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(headers: string[], rows: Record<string, unknown>[]): string {
  return [headers.join(','), ...rows.map((row) => headers.map((key) => csvEscape(row[key])).join(','))].join('\n') + '\n';
}

test.beforeAll(async () => {
  await fs.rm(reportsDir, { recursive: true, force: true });
  await fs.mkdir(reportsDir, { recursive: true });
});

test('security analyst audits account freeze behavior', async ({ page }) => {
  const queue = parseCsv(queueCsv);
  const eventById = new Map(events.map((event: any) => [event.event_id, event]));
  expect(new Set(queue.map((item) => item.queue_item_id)).size).toBe(queue.length);
  expect(new Set(queue.map((item) => item.event_id)).size).toBe(queue.length);
  expect(queue.every((item) => eventById.has(item.event_id))).toBe(true);
  const activeRole = roles[policy.active_role];
  expect(activeRole).toBeTruthy();

  const rows = queue.map((item) => {
    const event: any = eventById.get(item.event_id);
    const result = decide(event);
    const actionEnabled = result.decision === 'freeze'
      && item.assigned_role === policy.active_role
      && activeRole.can_freeze_account_types.includes(event.account_type);
    return { item, event, ...result, actionEnabled };
  });
  const freezeRows = rows.filter((row) => row.actionEnabled);
  expect(freezeRows.length).toBeLessThanOrEqual(activeRole.daily_freeze_limit);

  const fixedEpochMs = Date.parse(policy.fixed_now_utc);
  const currentStep = Math.floor(fixedEpochMs / 1000 / policy.totp.step_seconds);
  const totpRows = policy.totp.accepted_step_offsets.map((stepOffset: number) => {
    const stepIndex = currentStep + stepOffset;
    return {
      step_offset: stepOffset,
      step_index: stepIndex,
      issued_at_utc: new Date(stepIndex * policy.totp.step_seconds * 1000).toISOString().replace('.000Z', 'Z'),
      code: totpAt(stepIndex),
      accepted: true,
    };
  });
  const currentTotp = totpRows.find((row: any) => row.step_offset === 0)?.code;
  expect(currentTotp).toMatch(new RegExp(`^\\d{${policy.totp.digits}}$`));

  const captured: Array<{ url: string; method: string; body: Record<string, string>; statusCode: number }> = [];
  const browserRequests: string[] = [];
  page.on('request', (request) => browserRequests.push(request.url()));
  const browserPolicy = { ...policy, admin_session_id: activeRole.session_id };
  await page.addInitScript((fixedNow) => {
    const fixed = new Date(fixedNow).valueOf();
    Date.now = () => fixed;
  }, policy.fixed_now_utc);
  await page.route('**/api/risk-login', (route) => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(events) }));
  await page.route('**/api/freeze-policy', (route) => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(browserPolicy) }));
  await page.route('**/api/accounts/*/freeze', async (route) => {
    captured.push({
      url: new URL(route.request().url()).pathname,
      method: route.request().method(),
      body: route.request().postDataJSON(),
      statusCode: 200,
    });
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true }) });
  });

  await page.goto('/');
  await expect(page.locator('[data-testid=risk-list] article')).toHaveCount(events.length);
  const renderedOrder = await page.locator('[data-testid=risk-list] article').evaluateAll((nodes) => nodes.map((node) => (node as HTMLElement).dataset.accountId));
  const expectedOrder = [...events]
    .sort((left: any, right: any) => right.risk_score - left.risk_score || left.event_id.localeCompare(right.event_id))
    .map((event: any) => event.account_id);
  expect(renderedOrder).toEqual(expectedOrder);

  const decisionRows = [];
  for (const row of rows) {
    const card = page.locator(`[data-account-id=${row.event.account_id}]`);
    const badge = card.locator('[data-testid=decision-badge]');
    const button = card.locator('[data-testid=freeze-button]');
    await expect(badge).toHaveText(row.decision);
    if (row.actionEnabled) await expect(button).toBeEnabled();
    else await expect(button).toBeDisabled();
    decisionRows.push({
      queue_item_id: row.item.queue_item_id,
      event_id: row.event.event_id,
      account_id: row.event.account_id,
      assigned_role: row.item.assigned_role,
      decision: await badge.innerText(),
      reason_code: row.reasonCode,
      action_enabled: await button.isEnabled(),
      visible_badge: await badge.innerText(),
    });
  }

  const primary = freezeRows[0];
  expect(primary).toBeTruthy();
  const focusRows: Array<Record<string, unknown>> = [];
  const captureFocus = async (orderIndex: number, context: string) => {
    const observed = await page.evaluate(() => {
      const active = document.activeElement as HTMLElement | null;
      const card = active?.closest('[data-account-id]') as HTMLElement | null;
      return {
        control: active?.dataset.testid || active?.tagName.toLowerCase() || '',
        account_id: card?.dataset.accountId || '',
      };
    });
    focusRows.push({ order_index: orderIndex, control: observed.control, context, account_id: observed.account_id });
    return observed;
  };

  const expectedFocus = ['risk-search', 'filter-high-risk', 'filter-review', 'freeze-button'];
  for (let index = 0; index < expectedFocus.length; index += 1) {
    await page.keyboard.press('Tab');
    const observed = await captureFocus(index + 1, index < 3 ? '页头' : '高风险消费者');
    expect(observed.control).toBe(expectedFocus[index]);
    if (index === 3) expect(observed.account_id).toBe(primary.event.account_id);
  }
  await page.keyboard.press('Enter');
  await expect(page.locator('[data-testid=freeze-dialog]')).toBeVisible();
  let observed = await captureFocus(5, '冻结对话框');
  expect(observed.control).toBe('freeze-reason');
  await page.locator('[data-testid=freeze-reason]').selectOption(primary.reasonCode);
  await page.keyboard.press('Tab');
  observed = await captureFocus(6, '冻结对话框');
  expect(observed.control).toBe('totp-code');
  await page.locator('[data-testid=totp-code]').fill(currentTotp);
  await page.keyboard.press('Tab');
  observed = await captureFocus(7, '冻结对话框');
  expect(observed.control).toBe('confirm-freeze');
  await page.keyboard.press('Enter');
  await expect(page.locator('[data-testid=freeze-dialog]')).not.toBeVisible();

  for (const row of freezeRows.slice(1)) {
    await page.locator(`[data-account-id=${row.event.account_id}] [data-testid=freeze-button]`).click();
    await page.locator('[data-testid=freeze-reason]').selectOption(row.reasonCode);
    await page.locator('[data-testid=totp-code]').fill(currentTotp);
    await page.locator('[data-testid=confirm-freeze]').click();
    await expect(page.locator('[data-testid=freeze-dialog]')).not.toBeVisible();
  }

  expect(captured).toHaveLength(freezeRows.length);
  const requiredBodyKeys = [...policy.freeze_request.body_keys].sort();
  for (const request of captured) {
    const source = freezeRows.find((row) => row.event.account_id === request.body.account_id);
    expect(source).toBeTruthy();
    expect(request.method).toBe(policy.freeze_request.method);
    expect(request.url).toBe(policy.freeze_request.url_template.replace('{account_id}', request.body.account_id));
    expect(Object.keys(request.body).sort()).toEqual(requiredBodyKeys);
    expect(request.body.event_id).toBe(source.event.event_id);
    expect(request.body.reason_code).toBe(source.reasonCode);
    expect(request.body.totp_code).toBe(currentTotp);
    expect(request.body.session_id).toBe(activeRole.session_id);
    expect(request.body.idempotency_key).toBe(`${request.body.account_id}:${request.body.event_id}:freeze`);
  }
  const restrictedAccounts = rows.filter((row) => !row.actionEnabled).map((row) => row.event.account_id);
  expect(captured.every((request) => !restrictedAccounts.includes(request.body.account_id))).toBe(true);
  expect(browserRequests.length).toBeGreaterThan(0);
  expect(browserRequests.every((url) => ['127.0.0.1', 'localhost'].includes(new URL(url).hostname))).toBe(true);

  const networkRows = captured.map((request) => {
    const source = freezeRows.find((row) => row.event.account_id === request.body.account_id);
    return {
      queue_item_id: source.item.queue_item_id,
      event_id: request.body.event_id,
      account_id: request.body.account_id,
      method: request.method,
      url: request.url,
      status_code: request.statusCode,
      reason_code: request.body.reason_code,
      session_id: request.body.session_id,
      idempotency_key: request.body.idempotency_key,
      totp_code: request.body.totp_code,
      body_keys: requiredBodyKeys.join('|'),
    };
  });

  await fs.writeFile(path.join(reportsDir, 'decision_matrix.csv'), toCsv(
    ['queue_item_id', 'event_id', 'account_id', 'assigned_role', 'decision', 'reason_code', 'action_enabled', 'visible_badge'], decisionRows,
  ));
  await fs.writeFile(path.join(reportsDir, 'totp_window.csv'), toCsv(
    ['step_offset', 'step_index', 'issued_at_utc', 'code', 'accepted'], totpRows,
  ));
  await fs.writeFile(path.join(reportsDir, 'network_receipts.csv'), toCsv(
    ['queue_item_id', 'event_id', 'account_id', 'method', 'url', 'status_code', 'reason_code', 'session_id', 'idempotency_key', 'totp_code', 'body_keys'], networkRows,
  ));
  await fs.writeFile(path.join(reportsDir, 'modal_focus.csv'), toCsv(
    ['order_index', 'control', 'context', 'account_id'], focusRows,
  ));
});
