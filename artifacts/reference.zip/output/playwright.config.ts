import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { defineConfig, devices } from 'playwright/test';

const inputRoot = process.env.ALE_INPUT_ROOT || process.cwd();
const outputRoot = process.env.ALE_OUTPUT_ROOT || path.join(inputRoot, 'output');
const policy = JSON.parse(fs.readFileSync(path.join(inputRoot, 'fixtures', 'freeze_policy.json'), 'utf8'));
const port = process.env.ALE_PORT || '4186';

export default defineConfig({
  testDir: path.join(outputRoot, 'tests'),
  workers: 1,
  fullyParallel: false,
  retries: 0,
  timeout: policy.runtime.task_timeout_seconds * 1000,
  reporter: [['line']],
  outputDir: path.join(inputRoot, '.playwright-artifacts'),
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    timezoneId: policy.runtime.timezone_id,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [{ name: policy.runtime.browser_project, use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'node scripts/static_server.mjs',
    cwd: inputRoot,
    url: `http://127.0.0.1:${port}`,
    reuseExistingServer: false,
    timeout: policy.runtime.server_startup_timeout_seconds * 1000,
  },
});
