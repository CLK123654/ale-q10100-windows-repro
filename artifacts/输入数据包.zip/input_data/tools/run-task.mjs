import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(toolsDir, '..');
const outputRoot = path.join(root, 'output');
const reportRoot = path.join(outputRoot, 'reports');
const candidateConfig = path.join(outputRoot, 'playwright.config.ts');
const candidateTest = path.join(outputRoot, 'tests', 'account_security_totp.spec.ts');

function cleanupReports() {
  fs.rmSync(reportRoot, { recursive: true, force: true });
  fs.rmSync(path.join(root, '.playwright-artifacts'), { recursive: true, force: true });
  fs.rmSync(path.join(root, 'test-results'), { recursive: true, force: true });
}

function cleanupOutput() {
  fs.rmSync(outputRoot, { recursive: true, force: true });
  fs.rmSync(path.join(root, '.playwright-artifacts'), { recursive: true, force: true });
  fs.rmSync(path.join(root, 'test-results'), { recursive: true, force: true });
}

function fail(message, code = 1) {
  cleanupOutput();
  process.stderr.write(`${message}\n`);
  process.exit(code);
}

cleanupReports();
const requiredInputs = [
  'app/security_console.html',
  'app/security_console.js',
  'fixtures/admin_roles.json',
  'fixtures/freeze_policy.json',
  'fixtures/risk_login_events.json',
  'queues/review_queue.csv',
  'scripts/static_server.mjs',
];
for (const relativePath of requiredInputs) {
  if (!fs.existsSync(path.join(root, relativePath))) fail(`缺少必需输入：${relativePath}`, 2);
}
for (const candidate of [candidateConfig, candidateTest]) {
  if (!fs.existsSync(candidate)) fail(`缺少完成版交付：${path.relative(root, candidate)}`, 2);
}

try {
  const require = createRequire(import.meta.url);
  const packageJson = require.resolve('playwright/package.json');
  const cli = path.join(path.dirname(packageJson), 'cli.js');
  const port = String(43_000 + (process.pid % 10_000));
  const run = spawnSync(process.execPath, [cli, 'test', '--config', candidateConfig], {
    cwd: root,
    encoding: 'utf8',
    timeout: 120_000,
    windowsHide: true,
    env: {
      ...process.env,
      ALE_INPUT_ROOT: root,
      ALE_OUTPUT_ROOT: outputRoot,
      ALE_PORT: port,
      PORT: port,
      NO_PROXY: '127.0.0.1,localhost',
    },
  });
  if (run.error || run.status !== 0) {
    const detail = [run.stdout, run.stderr, run.error?.message].filter(Boolean).join('\n');
    fail(detail || 'Playwright运行失败', run.status || 3);
  }
  const expectedPaths = [
    'playwright.config.ts',
    'reports/decision_matrix.csv',
    'reports/modal_focus.csv',
    'reports/network_receipts.csv',
    'reports/totp_window.csv',
    'tests/account_security_totp.spec.ts',
  ];
  const actualPaths = [];
  const collect = (directory, prefix = '') => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) collect(path.join(directory, entry.name), relative);
      else actualPaths.push(relative);
    }
  };
  collect(outputRoot);
  actualPaths.sort();
  if (JSON.stringify(actualPaths) !== JSON.stringify(expectedPaths)) {
    fail(`交付成员不符：${actualPaths.join(',')}`, 4);
  }
  fs.rmSync(path.join(root, '.playwright-artifacts'), { recursive: true, force: true });
  fs.rmSync(path.join(root, 'test-results'), { recursive: true, force: true });
  process.stdout.write('账号冻结控制台浏览器验收完成\n');
} catch (error) {
  fail(error?.stack ?? String(error), 6);
}
