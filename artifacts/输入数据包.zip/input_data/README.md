# 账号冻结控制台发布核查材料

这套材料来自脱敏的账号安全演练。app目录是待发布的静态控制台，fixtures/risk_login_events.json记录风险登录事件，fixtures/admin_roles.json给出值班角色权限，fixtures/freeze_policy.json定义裁决、TOTP和冻结请求合同，queues/review_queue.csv列出本次需要处理的队列项。页面只使用这些本地材料，不连接真实账号或风控服务。

从starter中的配置和测试骨架开始工作，将完成版写入output/playwright.config.ts和output/tests/account_security_totp.spec.ts。在本目录执行npm ci与npx playwright install chromium准备依赖，再运行npm run audit。报告写入output/reports。

输入目录保持不变。正式运行只访问本机回环地址，页面裁决和报告都应来自本次浏览器交互与实际请求。
