let events = [];
let policy = null;
let selected = null;
function decide(row){
  if(row.account_status === 'locked') return 'skip_locked';
  if(row.account_type === 'staff') return 'escalate_staff';
  if(row.account_type === 'service') return 'escalate_service';
  const hit = row.signals.some((signal) => policy.freeze_high_risk.accepted_signals.includes(signal));
  if(row.risk_score >= policy.freeze_high_risk.min_score && hit) return 'freeze';
  if(row.risk_score >= policy.review_min_score) return 'manual_review';
  return 'monitor';
}
function render(){
  const list = document.querySelector('[data-testid=risk-list]');
  list.innerHTML = '';
  for(const row of events.slice().sort((a,b)=>b.risk_score-a.risk_score || a.event_id.localeCompare(b.event_id))){
    const decision = decide(row);
    const card = document.createElement('article');
    card.dataset.accountId = row.account_id;
    card.innerHTML = '<h2>'+row.email+'</h2><p>'+row.event_id+' risk '+row.risk_score+'</p><span data-testid="decision-badge">'+decision+'</span>';
    const button = document.createElement('button');
    button.dataset.testid = 'freeze-button';
    button.textContent = '冻结账号';
    button.disabled = decision !== 'freeze';
    button.onclick = () => { selected = row; document.querySelector('[data-testid=freeze-dialog]').showModal(); };
    card.appendChild(button);
    list.appendChild(card);
  }
}
async function boot(){
  policy = await fetch('/api/freeze-policy').then((r)=>r.json());
  events = await fetch('/api/risk-login').then((r)=>r.json());
  render();
  document.querySelector('[data-testid=confirm-freeze]').addEventListener('click', async (event) => {
    event.preventDefault();
    const body = { account_id: selected.account_id, event_id: selected.event_id, reason_code: document.querySelector('[data-testid=freeze-reason]').value, totp_code: document.querySelector('[data-testid=totp-code]').value, session_id: policy.admin_session_id, idempotency_key: selected.account_id + ':' + selected.event_id + ':freeze' };
    await fetch('/api/accounts/' + selected.account_id + '/freeze', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    document.querySelector('[data-testid=freeze-dialog]').close();
  });
}
boot();