import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve("app");
const server = http.createServer(async (req, res) => {
  const target = req.url === "/" ? "security_console.html" : req.url.replace(/^\//, "");
  try {
    const body = await fs.readFile(path.join(root, target));
    if (target.endsWith(".html")) res.setHeader("content-type", "text/html; charset=utf-8");
    if (target.endsWith(".js")) res.setHeader("content-type", "text/javascript; charset=utf-8");
    res.end(body);
  } catch {
    res.statusCode = 404;
    res.end("not found");
  }
});
server.listen(process.env.PORT || 4186);
