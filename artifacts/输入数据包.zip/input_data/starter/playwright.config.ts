import { defineConfig } from 'playwright/test';

export default defineConfig({
  testDir: './tests',
  reporter: [['line']],
  use: {
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
});
