import { test, expect } from 'playwright/test';

test('完成账号冻结控制台的发布核查', async ({ page }) => {
  // 根据队列、风险事件、角色权限和冻结策略完成浏览器交互，并生成四份报告。
  await page.goto('/');
  await expect(page.getByTestId('risk-list')).toBeVisible();
});
